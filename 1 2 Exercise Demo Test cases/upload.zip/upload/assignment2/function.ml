ht(t);;
ht(t1);;
ht(t2);;

size(t);;
size(t1);;
size(t2);;

atoms(t1);;
atoms(t2);;
atoms(t3);;

truth t1 funi;;
truth t2 funi;;
truth t3 funi;;

nnf(t3);;
nnf(t4);;
nnf(t5);;

cnf(t6);;
cnf(t7);;

dnf(t7);;
dnf(t8);;

isTautology(t10);;
isTautology(t9);;

isSatisfiable(t10);;
isSatisfiable(t9);;
isSatisfiable(t2);;

entails t11 t12;;
entails t13 t14;;

isEquivalent t15 T;;
isEquivalent t16 t17;;
isEquivalent t18 t17;;
