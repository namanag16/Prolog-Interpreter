
isempty(s);;
isempty(s1);;

ismember 3 s2;;

issubset s1 s2;;

isequal s2 s1;;
isequal s2 s2;;
isequal s s1;;

union s1 s2;;
union s s1;; 

intersection s1 s2;;
intersection s1 s3;;

difference s1 s2;;
difference s1 s3;;

power s1;;

product s1 s2;;
