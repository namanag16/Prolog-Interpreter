let f_s1 x= if (x mod 3=0) then true else false;;
let f_s2 x= if (x mod 5=0) then true else false;;
let f_s3 x = if (x mod 15=0) then true else false;;



